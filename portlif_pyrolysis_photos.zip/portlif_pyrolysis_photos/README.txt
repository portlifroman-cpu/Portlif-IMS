Portlif IMS — реальные фотографии пиролизной установки

Папку photos/ нужно загрузить в корень репозитория portlifroman-cpu/Portlif-IMS в ветку ChatGPT.
GitHub: https://github.com/portlifroman-cpu/Portlif-IMS

Файлы:
heating-burners.jpg — нижняя система нагрева
condensation-system.jpg — конденсационная система
control-panel.jpg — щит управления
cabero-cooler.jpg — наружный воздушный охладитель CABERO
reactor-drive.jpg — привод, зубчатый венец реактора
reactor-loading-end.jpg — торцевая загрузочная часть реактора

HTML уже ссылается на /photos/имя файла, однако изображения появятся на сайте только после загрузки папки и успешного обновления сайта.
